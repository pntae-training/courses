echo -e "gss-ke02-9001.sh script"
