echo -e "this is test script"

