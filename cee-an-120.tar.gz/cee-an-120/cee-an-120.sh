echo -e "This is sample grading script"

