echo -e "clusterha script"

