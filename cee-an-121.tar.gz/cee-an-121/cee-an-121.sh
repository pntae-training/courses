#!/bin/bash
echo -e "This is test script"
